<template>
  <div class="about">
    <h1>This is an about page</h1>
    <Features/>
  </div>
</template>

<script>
import Features from '@/components/parts/Features.vue'

export default {
  components:{
    Features
  }  
}
</script>
